import Calcolatrice.calcS;
import Calcolatrice.calcA;
import CambioValute.cambioVal;
import Equivalenze.eq;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

class Main extends JFrame{
    JLabel Titolo, CS1, CS2, CA1, CA2, CV1, CV2;
    JPanel Pannello;
    JButton CalcolatriceSemplice, CalcolatriceAvanzata, CambioValute, Equivalenza, CheckUpdate;
    public Main(){
        super("ToolBox");
        setSize(400, 400);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        var a = new Azioni();

        Titolo = new JLabel("ToolBox V1.3", JLabel.CENTER);
        Titolo.setFont(new Font("Arial", Font.BOLD,35));
        add(Titolo, BorderLayout.NORTH);

        Pannello = new JPanel();
        Pannello.setLayout(null);
        Pannello.setBackground(Color.orange);

        CS1 = new JLabel("Calcolatrice", JLabel.CENTER);
        CS2 = new JLabel("Semplice", JLabel.CENTER);
        CA1 = new JLabel("Calcolatrice", JLabel.CENTER);
        CA2 = new JLabel("Avanzata", JLabel.CENTER);
        CV1 = new JLabel("Cambio", JLabel.CENTER);
        CV2 = new JLabel("Valute", JLabel.CENTER);

        CalcolatriceSemplice = new JButton("Calcolatrice Semplice");
        CalcolatriceSemplice.setFont(new Font("arial", Font.PLAIN,0));
        CalcolatriceSemplice.addActionListener(a);
        CalcolatriceSemplice.setLayout(new BorderLayout());
        CalcolatriceSemplice.add(CS1, BorderLayout.NORTH);
        CalcolatriceSemplice.add(CS2, BorderLayout.SOUTH);
        CalcolatriceSemplice.setBounds(25,50,130,40);
        Pannello.add(CalcolatriceSemplice);

        CalcolatriceAvanzata = new JButton("Calcolatrice Avanzata");
        CalcolatriceAvanzata.setFont(new Font("arial", Font.PLAIN,0));
        CalcolatriceAvanzata.addActionListener(a);
        CalcolatriceAvanzata.setLayout(new BorderLayout());
        CalcolatriceAvanzata.add(CA1, BorderLayout.NORTH);
        CalcolatriceAvanzata.add(CA2, BorderLayout.SOUTH);
        CalcolatriceAvanzata.setBounds(25,150,130,40);
        Pannello.add(CalcolatriceAvanzata);

        CambioValute = new JButton("Cambio Valute");
        CambioValute.setFont(new Font("arial", Font.PLAIN,0));
        CambioValute.addActionListener(a);
        CambioValute.setLayout(new BorderLayout());
        CambioValute.add(CV1, BorderLayout.NORTH);
        CambioValute.add(CV2, BorderLayout.SOUTH);
        CambioValute.setBounds(245,50,130,40);
        Pannello.add(CambioValute);

        Equivalenza = new JButton("Equivalenze");
        Equivalenza.addActionListener(a);
        Equivalenza.setBounds(245,150,130,40);
        Pannello.add(Equivalenza);

        CheckUpdate = new JButton("Check Update");
        CheckUpdate.addActionListener(a);
        CheckUpdate.setBounds(125,230,150,40);
        Pannello.add(CheckUpdate);

        add(Pannello);
        setVisible(true);
    }

    private static class Azioni implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            switch (e.getActionCommand()) {
                case "Calcolatrice Semplice":
                    calcS.main();
                    break;
                case "Calcolatrice Avanzata":
                    calcA.main();
                    break;
                case "Cambio Valute":
                    cambioVal.main();
                    break;
                case "Equivalenze":
                    eq.main();
                    break;
                case "Check Update":
                    openWebPage("https://github.com/AntonioSansica/ToolBox");
                    break;

               /*default:
                   System.out.println("test");
                   break;*/
            }
        }
    }

    public static void openWebPage(String url){
        try {
            java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
        }
        catch (java.io.IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args){new Main();}
}
