package Equivalenze;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class equivalenza extends JFrame{
    JPanel Pannello;
    JLabel EtichettaEq, EtichettaS, EtichettaD;
    JTextField CasellaS, CasellaD;
    JButton Cambio;
    JMenuBar Barra;
    JMenu Menu;
    JMenuItem Lunghezza, Km, Hm, Dam, m, dm, cm, mm;
    JMenuItem Massa, Kg, Hg, Dag, g, dg, cg, mg;
    JMenuItem Capacita, Kl, Hl, Dal, l, dl, cl, ml;

    public equivalenza() {
        super("Equivalenze");
        setSize(600, 300);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        var s = new AzioniS();
        var d = new AzioniD();
        var c = new AzioniC();

        Pannello = new JPanel();
        Pannello.setBackground(Color.orange);
        Pannello.setLayout(null);

        EtichettaEq = new JLabel("EQUIVALENZE", JLabel.CENTER);
        EtichettaEq.setFont(new Font("Arial", Font.BOLD,25));
        add(EtichettaEq, BorderLayout.NORTH);
        EtichettaS = new JLabel("", JLabel.CENTER);
        EtichettaS.setFont(new Font("Arial", Font.BOLD,15));
        EtichettaS.setBounds(50,40,100,30);
        Pannello.add(EtichettaS);
        EtichettaD = new JLabel("", JLabel.CENTER);
        EtichettaD.setFont(new Font("Arial", Font.BOLD,15));
        EtichettaD.setBounds(440,40,100,30);
        Pannello.add(EtichettaD);

        Lunghezza = new JMenuItem("--Lunghezza--");
        Km = new JMenuItem("Chilometri");
        Hm = new JMenuItem("Ettometri");
        Dam = new JMenuItem("Decametri");
        m = new JMenuItem("Metri");
        dm = new JMenuItem("Decimetri");
        cm = new JMenuItem("Centimetri");
        mm = new JMenuItem("Millimetri");

        Massa = new JMenuItem("--Massa--");
        Kg = new JMenuItem("Chilogrammi");
        Hg = new JMenuItem("Ettogrammi");
        Dag = new JMenuItem("Decagrammi");
        g = new JMenuItem("Grammi");
        dg = new JMenuItem("Decigrammi");
        cg = new JMenuItem("Centigrammi");
        mg = new JMenuItem("Milligrammi");

        Capacita = new JMenuItem("--Capacità--");
        Kl = new JMenuItem("Chilolitri");
        Hl = new JMenuItem("Ettolitri");
        Dal = new JMenuItem("Decalitri");
        l = new JMenuItem("Litri");
        dl = new JMenuItem("Decilitri");
        cl = new JMenuItem("Centilitri");
        ml = new JMenuItem("Millilitri");

        Km.addActionListener(s);
        Hm.addActionListener(s);
        Dam.addActionListener(s);
        m.addActionListener(s);
        dm.addActionListener(s);
        cm.addActionListener(s);
        mm.addActionListener(s);

        Kg.addActionListener(s);
        Hg.addActionListener(s);
        Dag.addActionListener(s);
        g.addActionListener(s);
        dg.addActionListener(s);
        cg.addActionListener(s);
        mg.addActionListener(s);

        Kl.addActionListener(s);
        Hl.addActionListener(s);
        Dal.addActionListener(s);
        l.addActionListener(s);
        dl.addActionListener(s);
        cl.addActionListener(s);
        ml.addActionListener(s);

        Barra = new JMenuBar();
        Barra.setBounds(205,15,60,20);
        Menu = new JMenu("Misura");
        Menu.add(Lunghezza);
        Menu.add(Km);
        Menu.add(Hm);
        Menu.add(Dam);
        Menu.add(m);
        Menu.add(dm);
        Menu.add(cm);
        Menu.add(mm);
        Menu.add(Massa);
        Menu.add(Kg);
        Menu.add(Hg);
        Menu.add(Dag);
        Menu.add(g);
        Menu.add(dg);
        Menu.add(cg);
        Menu.add(mg);
        Menu.add(Capacita);
        Menu.add(Kl);
        Menu.add(Hl);
        Menu.add(Dal);
        Menu.add(l);
        Menu.add(dl);
        Menu.add(cl);
        Menu.add(ml);
        Barra.add(Menu);
        Pannello.add(Barra);

        Lunghezza = new JMenuItem("--Lunghezza--");
        Km = new JMenuItem("Chilometri");
        Hm = new JMenuItem("Ettometri");
        Dam = new JMenuItem("Decametri");
        m = new JMenuItem("Metri");
        dm = new JMenuItem("Decimetri");
        cm = new JMenuItem("Centimetri");
        mm = new JMenuItem("Millimetri");

        Massa = new JMenuItem("--Massa--");
        Kg = new JMenuItem("Chilogrammi");
        Hg = new JMenuItem("Ettogrammi");
        Dag = new JMenuItem("Decagrammi");
        g = new JMenuItem("Grammi");
        dg = new JMenuItem("Decigrammi");
        cg = new JMenuItem("Centigrammi");
        mg = new JMenuItem("Milligrammi");

        Capacita = new JMenuItem("--Capacità--");
        Kl = new JMenuItem("Chilolitri");
        Hl = new JMenuItem("Ettolitri");
        Dal = new JMenuItem("Decalitri");
        l = new JMenuItem("Litri");
        dl = new JMenuItem("Decilitri");
        cl = new JMenuItem("Centilitri");
        ml = new JMenuItem("Millilitri");

        Km.addActionListener(d);
        Hm.addActionListener(d);
        Dam.addActionListener(d);
        m.addActionListener(d);
        dm.addActionListener(d);
        cm.addActionListener(d);
        mm.addActionListener(d);

        Kg.addActionListener(d);
        Hg.addActionListener(d);
        Dag.addActionListener(d);
        g.addActionListener(d);
        dg.addActionListener(d);
        cg.addActionListener(d);
        mg.addActionListener(d);

        Kl.addActionListener(d);
        Hl.addActionListener(d);
        Dal.addActionListener(d);
        l.addActionListener(d);
        dl.addActionListener(d);
        cl.addActionListener(d);
        ml.addActionListener(d);

        Barra = new JMenuBar();
        Barra.setBounds(335,15,60,20);
        Menu = new JMenu("Misura");
        Menu.add(Lunghezza);
        Menu.add(Km);
        Menu.add(Hm);
        Menu.add(Dam);
        Menu.add(m);
        Menu.add(dm);
        Menu.add(cm);
        Menu.add(mm);
        Menu.add(Massa);
        Menu.add(Kg);
        Menu.add(Hg);
        Menu.add(Dag);
        Menu.add(g);
        Menu.add(dg);
        Menu.add(cg);
        Menu.add(mg);
        Menu.add(Capacita);
        Menu.add(Kl);
        Menu.add(Hl);
        Menu.add(Dal);
        Menu.add(l);
        Menu.add(dl);
        Menu.add(cl);
        Menu.add(ml);
        Barra.add(Menu);
        Pannello.add(Barra);

        CasellaS = new JTextField("");
        CasellaS.setHorizontalAlignment(JTextField.RIGHT);
        CasellaS.setFont(new Font("Arial", Font.BOLD,35));
        CasellaS.setBounds(10,100,255,40);
        Pannello.add(CasellaS);

        CasellaD = new JTextField("");
        CasellaD.setHorizontalAlignment(JTextField.RIGHT);
        CasellaD.setFont(new Font("Arial", Font.BOLD,35));
        CasellaD.setBounds(335,100,255,40);
        Pannello.add(CasellaD);

        Cambio = new JButton("CAMBIO");
        Cambio.setFont(new Font("Arial", Font.BOLD,25));
        Cambio.setBounds(228,170, 145,40);
        Cambio.addActionListener(c);
        Pannello.add(Cambio);

        add(Pannello);
        setVisible(true);
    }

    private class AzioniS implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            EtichettaS.setText(e.getActionCommand());
        }
    }
    private class AzioniD implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            EtichettaD.setText(e.getActionCommand());
        }
    }
    private class AzioniC implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (CasellaD.getText().equals("")){
                switch (EtichettaS.getText()){
                    case "Chilometri":
                        switch (EtichettaD.getText()){
                            case "Chilometri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Ettometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Decametri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Metri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Decimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            case "Centimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100000));
                                break;
                            case "Millimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Ettometri":
                        switch (EtichettaD.getText()){
                            case "Chilometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Ettometri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Decametri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Metri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Decimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Centimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            case "Millimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Decametri":
                        switch (EtichettaD.getText()){
                            case "Chilometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Ettometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Decametri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Metri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Decimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Centimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Millimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Metri":
                        switch (EtichettaD.getText()){
                            case "Chilometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Ettometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Decametri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Metri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Decimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Centimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Millimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Decimetri":
                        switch (EtichettaD.getText()){
                            case "Chilometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Ettometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Decametri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Metri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Decimetri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Centimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Millimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Centimetri":
                        switch (EtichettaD.getText()){
                            case "Chilometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100000));
                                break;
                            case "Ettometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Decametri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Metri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Decimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Centimetri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Millimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Millimetri":
                        switch (EtichettaD.getText()){
                            case "Chilometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000000));
                                break;
                            case "Ettometri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100000));
                                break;
                            case "Decametri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Metri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Decimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Centimetri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Millimetri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Chilogrammi":
                        switch (EtichettaD.getText()){
                            case "Chilogrammi":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Ettogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Decagrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Grammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Decigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            case "Centigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100000));
                                break;
                            case "Milligrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Ettogrammi":
                        switch (EtichettaD.getText()){
                            case "Chilogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Ettogrammi":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Decagrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Grammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Decigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Centigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            case "Milligrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Decagrammi":
                        switch (EtichettaD.getText()){
                            case "Chilogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Ettogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Decagrammi":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Grammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Decigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Centigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Milligrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Grammi":
                        switch (EtichettaD.getText()){
                            case "Chilogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Ettogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Decagrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Grammi":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Decigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Centigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Milligrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Decigrammi":
                        switch (EtichettaD.getText()){
                            case "Chilogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Ettogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Decagrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Grammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Decigrammi":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Centigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Milligrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Centigrammi":
                        switch (EtichettaD.getText()){
                            case "Chilogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100000));
                                break;
                            case "Ettogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Decagrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Grammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Decigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Centigrammi":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Milligrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Milligrammi":
                        switch (EtichettaD.getText()){
                            case "Chilogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000000));
                                break;
                            case "Ettogrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100000));
                                break;
                            case "Decagrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Grammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Decigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Centigrammi":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Milligrammi":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Chilolitri":
                        switch (EtichettaD.getText()){
                            case "Chilolitri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Ettolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Decalitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Litro":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Decilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            case "Centolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100000));
                                break;
                            case "Millilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Ettolitri":
                        switch (EtichettaD.getText()){
                            case "Chilolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Ettolitri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Decalitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Litro":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Decilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Centolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            case "Millilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Decalitri":
                        switch (EtichettaD.getText()){
                            case "Chilolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Ettolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Decalitri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Litro":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Decilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Centolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            case "Millilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Litri":
                        switch (EtichettaD.getText()){
                            case "Chilolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Ettolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Decalitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Litri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Decilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Centolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            case "Millilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*1000));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Decilitri":
                        switch (EtichettaD.getText()){
                            case "Chilolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Ettolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Decalitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Litri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Decilitri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Centolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            case "Millilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*100));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Centolitri":
                        switch (EtichettaD.getText()){
                            case "Chilolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100000));
                                break;
                            case "Ettolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Decalitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Litro":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Decilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Centolitri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            case "Millilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())*10));
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;
                    case "Millitro":
                        switch (EtichettaD.getText()){
                            case "Chilolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000000));
                                break;
                            case "Ettolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100000));
                                break;
                            case "Decalitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10000));
                                break;
                            case "Litri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/1000));
                                break;
                            case "Decilitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/100));
                                break;
                            case "Centolitri":
                                CasellaD.setText(String.valueOf(Float.parseFloat(CasellaS.getText())/10));
                                break;
                            case "Millilitri":
                                CasellaD.setText(CasellaS.getText());
                                break;
                            default:
                                CasellaD.setText("Errore");
                                break;
                        }
                        break;

                    default:
                        CasellaD.setText("Errore");
                        break;
                }
            }else if(CasellaS.getText().equals("")){
                switch (EtichettaD.getText()){
                    case "Chilometri":
                        switch (EtichettaS.getText()){
                            case "Chilometri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Ettometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Decametri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Metri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Decimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            case "Centimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100000));
                                break;
                            case "Millimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Ettometri":
                        switch (EtichettaS.getText()){
                            case "Chilometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Ettometri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Decametri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Metri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Decimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Centimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            case "Millimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Decametri":
                        switch (EtichettaS.getText()){
                            case "Chilometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Ettometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Decametri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Metri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Decimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Centimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Millimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Metri":
                        switch (EtichettaS.getText()){
                            case "Chilometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Ettometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Decametri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Metri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Decimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Centimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Millimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Decimetri":
                        switch (EtichettaS.getText()){
                            case "Chilometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Ettometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Decametri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Metri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Decimetri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Centimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Millimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Centimetri":
                        switch (EtichettaS.getText()){
                            case "Chilometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100000));
                                break;
                            case "Ettometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Decametri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Metri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Decimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Centimetri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Millimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Millimetri":
                        switch (EtichettaS.getText()){
                            case "Chilometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000000));
                                break;
                            case "Ettometri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100000));
                                break;
                            case "Decametri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Metri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Decimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "centrimetri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Millimetri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Chilogrammi":
                        switch (EtichettaS.getText()){
                            case "Chilogrammi":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Ettogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Decagrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Grammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Decigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            case "Centigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100000));
                                break;
                            case "Milligrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Ettogrammi":
                        switch (EtichettaS.getText()){
                            case "Chilogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Ettogrammi":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Decagrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Grammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Decigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Centigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            case "Milligrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Decagrammi":
                        switch (EtichettaS.getText()){
                            case "Chilogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Ettogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Decagrammi":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Grammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Decigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Centigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Milligrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Grammi":
                        switch (EtichettaS.getText()){
                            case "Chilogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Ettogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Decagrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Grammi":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Decigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Centigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Milligrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Decigrammi":
                        switch (EtichettaS.getText()){
                            case "Chilogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Ettogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Decagrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Grammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Decigrammi":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Centigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Milligrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Centigrammi":
                        switch (EtichettaS.getText()){
                            case "Chilogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100000));
                                break;
                            case "Ettogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Decagrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Grammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Decigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Centigrammi":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Milligrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Milligrammi":
                        switch (EtichettaS.getText()){
                            case "Chilogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000000));
                                break;
                            case "Ettogrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100000));
                                break;
                            case "Decagrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Grammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Decigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Centigrammi":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Milligrammi":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                    case "Chilolitri":
                        switch (EtichettaS.getText()){
                            case "Chilolitri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Ettolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Decalitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Litri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Decilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            case "Centilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100000));
                                break;
                            case "Millilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Ettolitri":
                        switch (EtichettaS.getText()){
                            case "Chilolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Ettolitri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Decalitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Litri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Decilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Centilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            case "Millilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Decalitri":
                        switch (EtichettaS.getText()){
                            case "Chilolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Ettolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Decalitri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Litri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Decilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Centilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            case "Millilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Litri":
                        switch (EtichettaS.getText()){
                            case "Chilolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Ettolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Decalitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Litri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Decilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Centilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            case "Millilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*1000));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Decilitri":
                        switch (EtichettaS.getText()){
                            case "Chilolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Ettolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Decalitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Litri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Decilitri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Centilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            case "Millilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*100));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Centilitri":
                        switch (EtichettaS.getText()){
                            case "Chilolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100000));
                                break;
                            case "Ettolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Decalitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Litri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Decilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Centilitri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            case "Millilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())*10));
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                        break;
                    case "Millilitri":
                        switch (EtichettaS.getText()){
                            case "Chilolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000000));
                                break;
                            case "Ettolitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100000));
                                break;
                            case "Decalitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10000));
                                break;
                            case "Litri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/1000));
                                break;
                            case "Decilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/100));
                                break;
                            case "Centilitri":
                                CasellaS.setText(String.valueOf(Float.parseFloat(CasellaD.getText())/10));
                                break;
                            case "Millilitri":
                                CasellaS.setText(CasellaD.getText());
                                break;
                            default:
                                CasellaS.setText("Errore");
                                break;
                        }
                }
            }else{
                CasellaS.setText("Errore");
                CasellaD.setText("Errore");
            }
        }
    }

    public static void main(){
        new equivalenza();
    }
}

