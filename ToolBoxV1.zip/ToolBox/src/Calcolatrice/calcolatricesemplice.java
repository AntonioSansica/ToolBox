package Calcolatrice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calcolatricesemplice extends JFrame{
    JPanel Pannello;
    JTextField Testo;
    JButton Piu, Meno, Diviso, Per, Uguale, Cancella;
    JButton[] Numeri = new JButton[10];

    private calcolatricesemplice() {

        // Costruzione Finestra Calcolatrice Semplice
        super("Calcoltrice Semplice");
        setSize(400, 400);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Dichiarazione JPanel e Area Testo
        Testo = new JTextField();
        Testo.setHorizontalAlignment(JTextField.RIGHT);
        Testo.setEnabled(true);
        Testo.setDisabledTextColor(Color.BLACK);
        Testo.setPreferredSize(new Dimension(400, 85));
        Testo.setBackground(Color.white);
        Testo.setFont(new Font("Arial", Font.PLAIN, 40));
        add(Testo, BorderLayout.NORTH);

        Pannello = new JPanel();
        Pannello.setBackground(Color.red);
        Pannello.setLayout(new GridLayout(4, 4));

        //Creazione bottoni essenziali ed implementazione classe Azioni
        JButton Piu = new JButton("+");
        JButton Meno = new JButton("-");
        JButton Per = new JButton("*");
        JButton Cancella = new JButton("C");
        JButton Uguale = new JButton("=");
        JButton Diviso = new JButton("/");

        Azioni e = new Azioni();

        e.iniz();       //inizializzazione vettore per operazioni

        Piu.addActionListener(e);
        Meno.addActionListener(e);
        Per.addActionListener(e);
        Diviso.addActionListener(e);
        Uguale.addActionListener(e);
        Cancella.addActionListener(e);

        for (int i = 9; i != -1; i--) {
            Numeri[i] = new JButton("" + i);
            Numeri[i].addActionListener(e);
        }

        //Aggiunta Bottoni al JPanel dichiarato
        Pannello.add(Numeri[9]);
        Pannello.add(Numeri[8]);
        Pannello.add(Numeri[7]);
        Pannello.add(Piu);
        Pannello.add(Numeri[6]);
        Pannello.add(Numeri[5]);
        Pannello.add(Numeri[4]);
        Pannello.add(Meno);
        Pannello.add(Numeri[3]);
        Pannello.add(Numeri[2]);
        Pannello.add(Numeri[1]);
        Pannello.add(Per);
        Pannello.add(Cancella);
        Pannello.add(Numeri[0]);
        Pannello.add(Uguale);
        Pannello.add(Diviso);

        add(Pannello);          //Aggiunta del JPanel al Frame
        setVisible(true);       //Visualizzazione Frame

    }

    private class Azioni implements ActionListener {
        String[] Espressione = new String[100];     //Dichiarazione vettore che conterrà le operazioni svolte
        int i = 0;
        float Ris = 0;
        void iniz(){                                //Metodo inizializza vettore
            for (int k = 0; k < 100; k++){
                Espressione[k] = "";
            }
        }
        public void actionPerformed(ActionEvent e) {        //metodo azione alla pressione del bottone
            switch (e.getActionCommand()) {
                case "C":                                   //Reinizializzazione del vettore, della variabile Ris, della varibile di iterazione i  alla pressione del tasto C
                    Espressione = new String[100];
                    Testo.setText("Ciao");
                    iniz();
                    Ris = 0;
                    i = 0;
                    break;
                case "=":                                  //Calcolo e stampa a schermo dell'operazione corrente
                    Ris = RisolviEspressione(Espressione, i);
                    Testo.setText(String.valueOf(Ris));
                    break;
                default:
                    if (!e.getActionCommand().equals("+") && !e.getActionCommand().equals("-") && !e.getActionCommand().equals("*") && !e.getActionCommand().equals("/")) {
                        Espressione[i] += e.getActionCommand();
                        Testo.setText(Espressione[i]);
                    }
                    else {                                                              //finchè non viene premuto un Bottone Operando, C o =, vi è la possibilità di scrivere il numero desiderato
                        if (i == 2 || (i > 3 && i % 2 == 0)) {                          //alla pressione di un tasto Operando, prima si controlla il valore di i e se rispecchia una delle condizioni
                            Ris = RisolviEspressione(Espressione, i);                   //descritte si calcola il risultato e si sostituisce al valore della posizione corrente nel vettore
                            Espressione[i] = String.valueOf(Ris);                       //fatto ciò si incrementa di 1 la varibile i e si inserisce nel vettore l'operando ed infine si incrementa nuovamente la varibile i
                        }
                        i++;
                        Espressione[i] = e.getActionCommand();
                        Testo.setText(Espressione[i]);
                        i++;
                    }
                    break;
            }
        }

        public float RisolviEspressione(String[] Espressione, int a){                   //metodo risolvi operazione da svolgere
            float ris = 0;
            float b = Float.parseFloat(Espressione[a-2]);
            float c = Float.parseFloat(Espressione[a]);

            switch (Espressione[a-1]){
                case "+":
                    ris = b + c;
                    break;
                case "-":
                    ris = b-c;
                    break;
                case "*":
                    ris = b*c;
                    break;
                case "/":
                    ris = b/c;
                    break;
                default:
                    ris = 0;
            }

            return ris;
        }
    }
    public static void main(){
        new calcolatricesemplice();
    }
}
