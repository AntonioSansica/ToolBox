package CambioValute;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class cambioVal extends JFrame {
    JPanel Pannello1, Pannello2, Pannello3;
    static JLabel Titolo, valInput, valOutput;
    static JTextField Input, Output;
    JMenuBar BarInput, BarOutput;
    JMenu MenuInput, MenuOutput;
    JMenuItem Dollaro, Euro, Yen, Sterlina;
    JButton Converti, Cancella;

    public cambioVal(){
        super("Cambio Valute");
        setSize(600, 200);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        new BorderLayout();
        var aI = new AzioniI();
        var aO = new AzioniO();
        var aB = new AzioniB();

        Titolo = new JLabel("Cambio Valute", JLabel.CENTER);
        Titolo.setFont(new Font("Arial", Font.BOLD,25));
        add(Titolo, BorderLayout.NORTH);

        Pannello1 = new JPanel();
        Pannello1.setPreferredSize(new Dimension(150,175));
        Pannello1.setBackground(Color.orange);
        Pannello1.setLayout(null);
        add(Pannello1, BorderLayout.LINE_START);
        Pannello2 = new JPanel();
        Pannello2.setPreferredSize(new Dimension(225,175));
        Pannello2.setBackground(Color.orange);
        Pannello2.setLayout(null);
        add(Pannello2);
        Pannello3 = new JPanel();
        Pannello3.setPreferredSize(new Dimension(225,175));
        Pannello3.setBackground(Color.orange);
        Pannello3.setLayout(null);
        add(Pannello3, BorderLayout.LINE_END);

        Input = new JTextField("Input");
        Input.setHorizontalAlignment(JTextField.RIGHT);
        Input.setFont(new Font("Arial", Font.PLAIN, 15));
        Input.setBounds(10,20, 125,20);
        Pannello1.add(Input);
        Output = new JTextField("Output", JTextField.RIGHT);
        Output.setHorizontalAlignment(JTextField.RIGHT);
        Output.setFont(new Font("Arial", Font.PLAIN, 15));
        Output.setBounds(10,50, 125,20);
        Pannello1.add(Output);

        Converti = new JButton("converti");
        Converti.addActionListener(aB);
        Converti.setFont(new Font("Arial", Font.PLAIN, 15));
        Converti.setBounds(23,80,100,20);
        Pannello1.add(Converti);
        Cancella = new JButton("cancella");
        Cancella.addActionListener(aB);
        Cancella.setFont(new Font("Arial", Font.PLAIN, 15));
        Cancella.setBounds(23,110,100,20);
        Pannello1.add(Cancella);

        BarInput = new JMenuBar();
        BarInput.setBounds(70,20,80,20);
        MenuInput = new JMenu("Valore Input");
        Dollaro = new JMenuItem("Dollaro");
        Dollaro.addActionListener(aI);
        Euro = new JMenuItem("Euro");
        Euro.addActionListener(aI);
        Yen = new JMenuItem("Yen");
        Yen.addActionListener(aI);
        Sterlina = new JMenuItem("Sterlina");
        Sterlina.addActionListener(aI);
        MenuInput.add(Dollaro);
        MenuInput.add(Euro);
        MenuInput.add(Yen);
        MenuInput.add(Sterlina);
        BarInput.add(MenuInput);
        Pannello2.add(BarInput);

        valInput = new JLabel("Sterlina");
        valInput.setHorizontalAlignment(JLabel.CENTER);
        valInput.setFont(new Font("Arial", Font.PLAIN, 20));
        valInput.setBounds(70,70,80,30);
        Pannello2.add(valInput);

        BarOutput = new JMenuBar();
        BarOutput.setBounds(70,20,90,20);
        MenuOutput = new JMenu("Valore Output");
        Dollaro = new JMenuItem("Dollaro");
        Dollaro.addActionListener(aO);
        Euro = new JMenuItem("Euro");
        Euro.addActionListener(aO);
        Yen = new JMenuItem("Yen");
        Yen.addActionListener(aO);
        Sterlina = new JMenuItem("Sterlina");
        Sterlina.addActionListener(aO);
        MenuOutput.add(Dollaro);
        MenuOutput.add(Euro);
        MenuOutput.add(Yen);
        MenuOutput.add(Sterlina);
        BarOutput.add(MenuOutput);
        Pannello3.add(BarOutput);

        valOutput = new JLabel("Sterlina");
        valOutput.setHorizontalAlignment(JLabel.CENTER);
        valOutput.setFont(new Font("Arial", Font.PLAIN, 20));
        valOutput.setBounds(70,70,80,30);
        Pannello3.add(valOutput);


        setVisible(true);
    }

    private static class AzioniI implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            switch (e.getActionCommand()) {
                case "Dollaro" -> valInput.setText("Dollaro");
                case "Euro" -> valInput.setText("Euro");
                case "Yen" -> valInput.setText("Yen");
                default -> valInput.setText("Sterlina");
            }
        }
    }
    private static class AzioniO implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            switch (e.getActionCommand()) {
                case "Dollaro" -> valOutput.setText("Dollaro");
                case "Euro" -> valOutput.setText("Euro");
                case "Yen" -> valOutput.setText("Yen");
                default -> valOutput.setText("Sterlina");
            }
        }
    }

    private static class AzioniB implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("converti")){
                switch (valInput.getText()){
                    case "Dollaro":
                        switch (valOutput.getText()) {
                            case "Dollaro" -> Output.setText(Input.getText());
                            case "Euro" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 0.9) * 100.0) / 100.0));
                            case "Yen" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 106.9) * 100.0) / 100.0));
                            case "Sterlina" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 0.8) * 100.0) / 100.0));
                        }
                        break;
                    case "Euro":
                        switch (valOutput.getText()) {
                            case "Euro" -> Output.setText(Input.getText());
                            case "Dollaro" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 1.1) * 100.0) / 100.0));
                            case "Yen" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 118.6) * 100.0) / 100.0));
                            case "Sterlina" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 0.89) * 100.0) / 100.0));
                        }
                        break;
                    case "Yen":
                        switch (valOutput.getText()) {
                            case "Euro" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 0.008) * 100.0) / 100.0));
                            case "Dollaro" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 0.009) * 100.0) / 100.0));
                            case "Yen" -> Output.setText(Input.getText());
                            case "Sterlina" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 0.007) * 100.0) / 100.0));
                        }
                        break;
                    case "Sterlina":
                        switch (valOutput.getText()) {
                            case "Euro" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 1.13) * 100.0) / 100.0));
                            case "Dollaro" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 1.25) * 100.0) / 100.0));
                            case "Yen" -> Output.setText(String.valueOf(Math.round((Float.parseFloat(Input.getText()) * 113.15) * 100.0) / 100.0));
                            case "Sterlina" -> Output.setText(Input.getText());
                        }
                        break;
                }
            } else {
                Input.setText("Input");
                Output.setText("Output");
            }
        }
    }

    public static void main(){
        new cambioVal();
    }
}
