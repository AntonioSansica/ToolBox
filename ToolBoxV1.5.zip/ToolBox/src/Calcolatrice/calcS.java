package Calcolatrice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calcS extends JFrame{
    JPanel Pannello1, Pannello2, SubPannello1, SubPannello2;
    static JTextField Testo;
    JButton Piu, Meno, Diviso, Per, Uguale, Cancella, Del, Ans, Punto, Negativo;
    JButton[] Numeri = new JButton[10];

    private calcS() {
        super("Calcoltrice Semplice");
        setSize(400, 400);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        new BorderLayout();
        var a = new Azioni();
        a.iniz();

        Pannello1 = new JPanel();
        Pannello1.setPreferredSize(new Dimension(400,80));
        Pannello1.setBackground(Color.orange);
        Pannello1.setLayout(null);
        add(Pannello1, BorderLayout.NORTH);

        Testo = new JTextField("");
        Testo.setHorizontalAlignment(JTextField.RIGHT);
        Testo.setBounds(20,10,360,60);
        Testo.setFont(new Font("Arial", Font.BOLD,30));
        Pannello1.add(Testo);


        Pannello2 = new JPanel();
        Pannello2.setPreferredSize(new Dimension(400,285));
        Pannello2.setBackground(Color.black);
        Pannello2.setLayout(new BorderLayout());
        add(Pannello2, BorderLayout.SOUTH);

        SubPannello1 = new JPanel();
        SubPannello1.setPreferredSize(new Dimension(250,285));
        SubPannello1.setBackground(Color.orange);
        SubPannello1.setLayout(new FlowLayout(FlowLayout.CENTER,15,10));
        Pannello2.add(SubPannello1, BorderLayout.LINE_START);

        SubPannello2 = new JPanel();
        SubPannello2.setPreferredSize(new Dimension(150,320));
        SubPannello2.setBackground(Color.orange);
        SubPannello2.setLayout(new FlowLayout(FlowLayout.CENTER,15,10));
        Pannello2.add(SubPannello2, BorderLayout.LINE_END);

        for (int i = 9; i > -1; i--){
            Numeri[i] = new JButton(""+i);
            Numeri[i].addActionListener(a);
            Numeri[i].setPreferredSize(new Dimension(60,60));
            if (!Numeri[i].getText().equals("0"))
                SubPannello1.add(Numeri[i]);
        }

        Piu = new JButton("+");
        Piu.setPreferredSize(new Dimension(60,60));
        Piu.addActionListener(a);
        Meno = new JButton("-");
        Meno.setPreferredSize(new Dimension(60,60));
        Meno.addActionListener(a);
        Per = new JButton("*");
        Per.setPreferredSize(new Dimension(60,60));
        Per.addActionListener(a);
        Diviso = new JButton(":");
        Diviso.setPreferredSize(new Dimension(60,60));
        Diviso.addActionListener(a);
        Cancella = new JButton("C");
        Cancella.setPreferredSize(new Dimension(60,60));
        Cancella.setBackground(Color.red);
        Cancella.addActionListener(a);
        Del = new JButton("Del");
        Del.setPreferredSize(new Dimension(60,60));
        Del.setBackground(Color.red);
        Del.addActionListener(a);
        Ans = new JButton("Ans");
        Ans.setPreferredSize(new Dimension(60,60));
        Ans.addActionListener(a);
        Uguale = new JButton("=");
        Uguale.setPreferredSize(new Dimension(60,60));
        Uguale.addActionListener(a);
        Punto = new JButton(".");
        Punto.setPreferredSize(new Dimension(60,60));
        Punto.addActionListener(a);
        Negativo = new JButton("(-)");
        Negativo.setPreferredSize(new Dimension(60,60));
        Negativo.addActionListener(a);

        SubPannello1.add(Negativo);
        SubPannello1.add(Numeri[0]);
        SubPannello1.add(Punto);

        SubPannello2.add(Del);
        SubPannello2.add(Cancella);
        SubPannello2.add(Per);
        SubPannello2.add(Diviso);
        SubPannello2.add(Piu);
        SubPannello2.add(Meno);
        SubPannello2.add(Ans);
        SubPannello2.add(Uguale);

        setVisible(true);
    }

    private static class Azioni implements ActionListener{
        String[] Espressione = new String[100];
        int i = 0;
        float Ris = 0;
        float Ans = 0;
        void iniz(){
            for (int k = 0; k < 100; k++){
                Espressione[k] = "";
            }
        }
        public void actionPerformed(ActionEvent e) {
            switch (e.getActionCommand()){
                case "C":
                    iniz();
                    i = 0;
                    Testo.setText("");
                    break;
                case "Del":
                    if (!Testo.getText().equals(String.valueOf(Ris))) {
                        Espressione[i] = Espressione[i].substring(0, Espressione[i].length() - 1);
                        Testo.setText(Espressione[i]);
                    }
                    break;
                case "=":
                    Ris = RisolviEspressione(Espressione, i);
                    Ans = Ris;
                    Testo.setText(String.valueOf(Ris));
                    break;
                case "(-)":
                    switch (Espressione[i]){
                        case "+":
                        case "-":
                        case ":":
                        case "*":
                            break;
                        default:
                            Espressione[i] = "-"+ Espressione[i];
                            Testo.setText(Espressione[i]);
                            break;
                    }
                    break;
                case ".":
                    Espressione[i] += ".";
                    Testo.setText(Espressione[i]);
                    break;
                case "Ans":
                    Espressione[i] = String.valueOf(Ans);
                    Testo.setText(String.valueOf(Ans));
                    break;
                default:
                    if (!e.getActionCommand().equals("+") && !e.getActionCommand().equals("-") && !e.getActionCommand().equals("*") && !e.getActionCommand().equals(":")) {
                        Espressione[i] += e.getActionCommand();
                        Testo.setText(Espressione[i]);
                    }
                    else {
                        if (i == 2 || (i > 3 && i % 2 == 0)) {
                            Ris = RisolviEspressione(Espressione, i);
                            Espressione[i] = String.valueOf(Ris);
                        }
                        i++;
                        Espressione[i] = e.getActionCommand();
                        Testo.setText(Espressione[i]);
                        i++;
                    }
                    break;
            }
        }

        public float RisolviEspressione(String[] Espressione, int a){
            float ris = 0;
            float b = Float.parseFloat(Espressione[a-2]);
            float c = Float.parseFloat(Espressione[a]);

            ris = switch (Espressione[a - 1]) {
                case "+" -> b + c;
                case "-" -> b - c;
                case "*" -> b * c;
                case ":" -> b / c;
                default -> 0;
            };

            return ris;
        }
    }
    public static void main(){
        new calcS();
    }
}