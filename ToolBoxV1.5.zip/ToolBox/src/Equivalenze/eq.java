package Equivalenze;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class eq extends JFrame{
    JPanel Pannello;
    static JLabel EtichettaEq, EtichettaS, EtichettaD;
    static JTextField CasellaS, CasellaD;
    JMenuBar Barra;
    JMenu Menu, Lunghezza, Massa, Capacita;
    JMenuItem Km, Hm, Dam, m, dm, cm, mm;
    JMenuItem Kg, Hg, Dag, g, dg, cg, mg;
    JMenuItem Kl, Hl, Dal, l, dl, cl, ml;
    static String Es;

    public eq() {
        super("Equivalenze");
        setSize(600, 230);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        var s = new AzioniS();
        var d = new AzioniD();
        var c = new AzioniC();

        Pannello = new JPanel();
        Pannello.setBackground(Color.orange);
        Pannello.setLayout(null);

        EtichettaEq = new JLabel("EQUIVALENZE", JLabel.CENTER);
        EtichettaEq.setFont(new Font("Arial", Font.BOLD,25));
        add(EtichettaEq, BorderLayout.NORTH);
        EtichettaS = new JLabel("", JLabel.CENTER);
        EtichettaS.setFont(new Font("Arial", Font.BOLD,15));
        EtichettaS.setBounds(50,40,150,30);
        Pannello.add(EtichettaS);
        EtichettaD = new JLabel("", JLabel.CENTER);
        EtichettaD.setFont(new Font("Arial", Font.BOLD,15));
        EtichettaD.setBounds(390,40,150,30);
        Pannello.add(EtichettaD);

        Lunghezza = new JMenu("--Lunghezza--");
        Km = new JMenuItem("Chilometri");
        Hm = new JMenuItem("Ettometri");
        Dam = new JMenuItem("Decametri");
        m = new JMenuItem("Metri");
        dm = new JMenuItem("Decimetri");
        cm = new JMenuItem("Centimetri");
        mm = new JMenuItem("Millimetri");

        Massa = new JMenu("--Massa--");
        Kg = new JMenuItem("Chilogrammi");
        Hg = new JMenuItem("Ettogrammi");
        Dag = new JMenuItem("Decagrammi");
        g = new JMenuItem("Grammi");
        dg = new JMenuItem("Decigrammi");
        cg = new JMenuItem("Centigrammi");
        mg = new JMenuItem("Milligrammi");

        Capacita = new JMenu("--Capacità--");
        Kl = new JMenuItem("Chilolitri");
        Hl = new JMenuItem("Ettolitri");
        Dal = new JMenuItem("Decalitri");
        l = new JMenuItem("Litri");
        dl = new JMenuItem("Decilitri");
        cl = new JMenuItem("Centilitri");
        ml = new JMenuItem("Millilitri");

        Km.addActionListener(s);
        Hm.addActionListener(s);
        Dam.addActionListener(s);
        m.addActionListener(s);
        dm.addActionListener(s);
        cm.addActionListener(s);
        mm.addActionListener(s);

        Kg.addActionListener(s);
        Hg.addActionListener(s);
        Dag.addActionListener(s);
        g.addActionListener(s);
        dg.addActionListener(s);
        cg.addActionListener(s);
        mg.addActionListener(s);

        Kl.addActionListener(s);
        Hl.addActionListener(s);
        Dal.addActionListener(s);
        l.addActionListener(s);
        dl.addActionListener(s);
        cl.addActionListener(s);
        ml.addActionListener(s);

        Barra = new JMenuBar();
        Barra.setBounds(205,15,60,20);
        Menu = new JMenu("Misura");
        Menu.add(Lunghezza);
        Lunghezza.add(Km);
        Lunghezza.add(Hm);
        Lunghezza.add(Dam);
        Lunghezza.add(m);
        Lunghezza.add(dm);
        Lunghezza.add(cm);
        Lunghezza.add(mm);
        Menu.add(Massa);
        Massa.add(Kg);
        Massa.add(Hg);
        Massa.add(Dag);
        Massa.add(g);
        Massa.add(dg);
        Massa.add(cg);
        Massa.add(mg);
        Menu.add(Capacita);
        Capacita.add(Kl);
        Capacita.add(Hl);
        Capacita.add(Dal);
        Capacita.add(l);
        Capacita.add(dl);
        Capacita.add(cl);
        Capacita.add(ml);
        Barra.add(Menu);
        Pannello.add(Barra);

        Lunghezza = new JMenu("--Lunghezza--");
        Km = new JMenuItem("Chilometri");
        Hm = new JMenuItem("Ettometri");
        Dam = new JMenuItem("Decametri");
        m = new JMenuItem("Metri");
        dm = new JMenuItem("Decimetri");
        cm = new JMenuItem("Centimetri");
        mm = new JMenuItem("Millimetri");

        Massa = new JMenu("--Massa--");
        Kg = new JMenuItem("Chilogrammi");
        Hg = new JMenuItem("Ettogrammi");
        Dag = new JMenuItem("Decagrammi");
        g = new JMenuItem("Grammi");
        dg = new JMenuItem("Decigrammi");
        cg = new JMenuItem("Centigrammi");
        mg = new JMenuItem("Milligrammi");

        Capacita = new JMenu("--Capacità--");
        Kl = new JMenuItem("Chilolitri");
        Hl = new JMenuItem("Ettolitri");
        Dal = new JMenuItem("Decalitri");
        l = new JMenuItem("Litri");
        dl = new JMenuItem("Decilitri");
        cl = new JMenuItem("Centilitri");
        ml = new JMenuItem("Millilitri");

        Km.addActionListener(d);
        Hm.addActionListener(d);
        Dam.addActionListener(d);
        m.addActionListener(d);
        dm.addActionListener(d);
        cm.addActionListener(d);
        mm.addActionListener(d);

        Kg.addActionListener(d);
        Hg.addActionListener(d);
        Dag.addActionListener(d);
        g.addActionListener(d);
        dg.addActionListener(d);
        cg.addActionListener(d);
        mg.addActionListener(d);

        Kl.addActionListener(d);
        Hl.addActionListener(d);
        Dal.addActionListener(d);
        l.addActionListener(d);
        dl.addActionListener(d);
        cl.addActionListener(d);
        ml.addActionListener(d);

        Barra = new JMenuBar();
        Barra.setBounds(335,15,60,20);
        Menu = new JMenu("Misura");
        Menu.add(Lunghezza);
        Lunghezza.add(Km);
        Lunghezza.add(Hm);
        Lunghezza.add(Dam);
        Lunghezza.add(m);
        Lunghezza.add(dm);
        Lunghezza.add(cm);
        Lunghezza.add(mm);
        Menu.add(Massa);
        Massa.add(Kg);
        Massa.add(Hg);
        Massa.add(Dag);
        Massa.add(g);
        Massa.add(dg);
        Massa.add(cg);
        Massa.add(mg);
        Menu.add(Capacita);
        Capacita.add(Kl);
        Capacita.add(Hl);
        Capacita.add(Dal);
        Capacita.add(l);
        Capacita.add(dl);
        Capacita.add(cl);
        Capacita.add(ml);
        Barra.add(Menu);
        Pannello.add(Barra);

        CasellaS = new JTextField();
        CasellaS.setHorizontalAlignment(JTextField.RIGHT);
        CasellaS.setFont(new Font("Arial", Font.BOLD,35));
        CasellaS.setBounds(10,100,255,40);
        CasellaS.getDocument().addDocumentListener(c);
        Pannello.add(CasellaS);

        CasellaD = new JTextField("");
        CasellaD.setHorizontalAlignment(JTextField.RIGHT);
        CasellaD.setFont(new Font("Arial", Font.BOLD,35));
        CasellaD.setBounds(335,100,255,40);
        Pannello.add(CasellaD);

        add(Pannello);
        setVisible(true);
    }

    private static class AzioniS implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            EtichettaS.setText(e.getActionCommand());
            switch (EtichettaS.getText()) {
                case "Chilometri", "Ettometri", "Decametri", "Metri", "Decimetri", "Centimetri", "Millimtri" -> Es = "lunghezza";
                case "Chilolitri", "Ettolitri", "Decalitri", "Litri", "Decilitri", "Centilitri", "Millilitri" -> Es = "capacità";
                case "Chilgrammi", "Ettogrammi", "Decagrammi", "Grammi", "Decigrammi", "Centigrammi", "Milligrammi" -> Es = "massa";
            }
        }
    }
    static class AzioniD implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            EtichettaD.setText(e.getActionCommand());
        }
    }

    private static class AzioniC implements DocumentListener {
        String t = "";
        void testo(){
            switch (Es) {
                case "lunghezza" -> {
                    var c = new Lunghezza();
                    t = CasellaS.getText();

                    if (t.length() > 0)
                        c.situazione(t);
                    else
                        CasellaD.setText("");
                }
                case "massa" -> {
                    var c = new Massa();
                    t = CasellaS.getText();

                    if (t.length() > 0)
                        c.situazione(t);
                    else
                        CasellaD.setText("");
                }
                case "capacità" -> {
                    var c = new Capacita();
                    t = CasellaS.getText();

                    if (t.length() > 0)
                        c.situazione(t);
                    else
                        CasellaD.setText("");
                }
            }

        }
        public void insertUpdate(DocumentEvent e) {
            testo();
        }
        public void removeUpdate(DocumentEvent e) {
            testo();
        }
        public void changedUpdate(DocumentEvent e) {}
    }

    private static class Lunghezza {
        void situazione(String t) {
            var cambio = new Cambio();
            switch (EtichettaS.getText()) {
                case "Chilometri":
                    switch (EtichettaD.getText()) {
                        case "Chilometri" -> CasellaD.setText(CasellaS.getText());
                        case "Ettometri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Decametri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Metri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Decimetri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        case "Centimetri" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                        case "Millimetri" -> CasellaD.setText(cambio.Mmilione(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Ettometri":
                    switch (EtichettaD.getText()) {
                        case "Chilometri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Ettometri" -> CasellaD.setText(CasellaS.getText());
                        case "Decametri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Metri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Decimetri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Centimetri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        case "Millimetri" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Decametri":
                    switch (EtichettaD.getText()) {
                        case "Chilometri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Ettometri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Decametri" -> CasellaD.setText(CasellaS.getText());
                        case "Metri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Decimetri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Centimetri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Millimetri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Metri":
                    switch (EtichettaD.getText()) {
                        case "Chilometri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Ettometri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Decametri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Metri" -> CasellaD.setText(CasellaS.getText());
                        case "Decimetri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Centimetri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Millimetri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Decimetri":
                    switch (EtichettaD.getText()) {
                        case "Chilometri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Ettometri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Decametri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Metri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Decimetri" -> CasellaD.setText(CasellaS.getText());
                        case "Centimetri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Millimetri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Centimetri":
                    switch (EtichettaD.getText()) {
                        case "Chilometri" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                        case "Ettometri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Decametri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Metri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Decimetri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Centimetri" -> CasellaD.setText(CasellaS.getText());
                        case "Millimetri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Millimetri":
                    switch (EtichettaD.getText()) {
                        case "Chilometri" -> CasellaD.setText(cambio.Dmilione(CasellaS.getText()));
                        case "Ettometri" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                        case "Decametri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Metri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Decimetri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Centimetri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Millimetri" -> CasellaD.setText(CasellaS.getText());
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                default: CasellaD.setText("Errore");
            }
        }
    }

    private static class Massa{
        void situazione(String t) {
            var cambio = new Cambio();
            switch (EtichettaS.getText()) {
                case "Chilogrammi":
                    switch (EtichettaD.getText()) {
                        case "Chilogrammi" -> CasellaD.setText(CasellaS.getText());
                        case "Ettogrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Decagrammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Grammi" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Decigrammi" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        case "Centigrammi" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                        case "Milligrammi" -> CasellaD.setText(cambio.Mmilione(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Ettogrammi":
                    switch (EtichettaD.getText()) {
                        case "Chilogrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Ettogrammi" -> CasellaD.setText(CasellaS.getText());
                        case "Decagrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Grammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Decigrammi" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Centigrammi" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        case "Milligrammi" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Decagrammi":
                    switch (EtichettaD.getText()) {
                        case "Chilogrammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Ettogrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Decagrammi" -> CasellaD.setText(CasellaS.getText());
                        case "Grammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Decigrammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Centigrammi" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Milligrammi" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Grammi":
                    switch (EtichettaD.getText()) {
                        case "Chilogrammi" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Ettogrammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Decagrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Grammi" -> CasellaD.setText(CasellaS.getText());
                        case "Decigrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Centigrammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Milligrammi" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Decigrammi":
                    switch (EtichettaD.getText()) {
                        case "Chilogrammi" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Ettogrammi" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Decagrammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Grammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Decigrammi" -> CasellaD.setText(CasellaS.getText());
                        case "Centigrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Milligrammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Centigrammi":
                    switch (EtichettaD.getText()) {
                        case "Chilogrammi" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                        case "Ettogrammi" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Decagrammi" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Grammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Decigrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Centigrammi" -> CasellaD.setText(CasellaS.getText());
                        case "Milligrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Milligrammi":
                    switch (EtichettaD.getText()) {
                        case "Chilogrammi" -> CasellaD.setText(cambio.Dmilione(CasellaS.getText()));
                        case "Ettogrammi" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                        case "Decagrammi" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Grammi" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Decigrammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Centigrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Milligrammi" -> CasellaD.setText(CasellaS.getText());
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                default: CasellaD.setText("Errore");
            }
        }
    }

    private static class Capacita{
        void situazione(String t) {
            var cambio = new Cambio();
            switch (EtichettaS.getText()) {
                case "Chilolitri":
                    switch (EtichettaD.getText()) {
                        case "Chilolitri" -> CasellaD.setText(CasellaS.getText());
                        case "Ettolitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Decalitri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Litro" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Decilitri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        case "Centolitri" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                        case "Millilitri" -> CasellaD.setText(cambio.Mmilione(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Ettolitri":
                    switch (EtichettaD.getText()) {
                        case "Chilolitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Ettolitri" -> CasellaD.setText(CasellaS.getText());
                        case "Decalitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Litro" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Decilitri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Centolitri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        case "Millilitri" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Decalitri":
                    switch (EtichettaD.getText()) {
                        case "Chilolitri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Ettolitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Decalitri" -> CasellaD.setText(CasellaS.getText());
                        case "Litro" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Decilitri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Centolitri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        case "Millilitri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Litri":
                    switch (EtichettaD.getText()) {
                        case "Chilolitri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Ettolitri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Decalitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Litri" -> CasellaD.setText(CasellaS.getText());
                        case "Decilitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Centolitri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        case "Millilitri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Decilitri":
                    switch (EtichettaD.getText()) {
                        case "Chilolitri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Ettolitri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Decalitri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Litri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Decilitri" -> CasellaD.setText(CasellaS.getText());
                        case "Centolitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        case "Millilitri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Centilitri":
                    switch (EtichettaD.getText()) {
                        case "Chilolitri" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                        case "Ettolitri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Decalitri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Litro" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Decilitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Centolitri" -> CasellaD.setText(CasellaS.getText());
                        case "Millilitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                        default -> CasellaD.setText("Errore");
                    }
                    break;
                case "Millitro":
                    switch (EtichettaD.getText()) {
                        case "Chilolitri" -> CasellaD.setText(cambio.Dmilione(CasellaS.getText()));
                        case "Ettolitri" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                        case "Decalitri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                        case "Litri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                        case "Decilitri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                        case "Centolitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                        case "Millilitri" -> CasellaD.setText(CasellaS.getText());
                        default -> CasellaD.setText("Errore");
                    }
                    break;
            }
        }
    }

    private static class Cambio {
        String Ddieci(String a){
            return String.valueOf(Float.parseFloat(a)/10);
        }
        String Dcento(String a){
            return String.valueOf(Float.parseFloat(a)/100);
        }
        String Dmille(String a){
            return String.valueOf(Float.parseFloat(a)/1000);
        }
        String Ddmila(String a){
            return String.valueOf(Float.parseFloat(a)/10000);
        }
        String Dcmila(String a){
            return String.valueOf(Float.parseFloat(a)/100000);
        }
        String Dmilione(String a){
            return String.valueOf(Float.parseFloat(a)/1000000);
        }
        String Mdieci(String a){
            return String.valueOf(Float.parseFloat(a)*10);
        }
        String Mcento(String a){
            return String.valueOf(Float.parseFloat(a)*100);
        }
        String Mmille(String a){
            return String.valueOf(Float.parseFloat(a)*1000);
        }
        String Mdmila(String a){
            return String.valueOf(Float.parseFloat(a)*10000);
        }
        String Mcmila(String a){
            return String.valueOf(Float.parseFloat(a)*100000);
        }
        String Mmilione(String a){
            return String.valueOf(Float.parseFloat(a)*1000000);
        }
    }

    public static void main(){
        new eq();
    }
}



