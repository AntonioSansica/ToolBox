package CambioValute;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class cambiovalute extends JFrame{
    JPanel Pannello, Pannello2, Pannello3;
    JLabel DollEu, DollSter, DollYen, SterEu, SterYen, EuYen;
    JTextField DollEu1, DollEu2, DollSter1, DollSter2, DollYen1, DollYen2, SterEu1, SterEu2, SterYen1, SterYen2, EuYen1, EuYen2;
    JButton Cambio, Cancella;

    public cambiovalute(){
        super("Cambio Valute");
        setSize(700, 600);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Pannello = new JPanel();
        Pannello.setBackground(Color.cyan);
        Pannello.setLayout(new GridLayout(6,1));
        Pannello2 = new JPanel();
        Pannello2.setLayout((new GridLayout(6,1)));
        Pannello3 = new JPanel();
        Pannello3.setBackground(Color.orange);
        Pannello3.setLayout(new GridLayout(6,1));

        DollEu1 = new JTextField("0.0");
        DollEu1.setHorizontalAlignment(JTextField.LEFT);
        DollEu1.setPreferredSize(new Dimension(250, 75));
        DollEu1.setFont(new Font("Arial", Font.PLAIN, 25));
        DollEu = new JLabel("Dollaro - Euro", JLabel.CENTER);
        DollEu.setPreferredSize(new Dimension(200,75));
        DollEu2 = new JTextField("0.0");
        DollEu2.setHorizontalAlignment(JTextField.RIGHT);
        DollEu2.setPreferredSize(new Dimension(250, 75));
        DollEu2.setFont(new Font("Arial", Font.PLAIN, 25));
        Pannello.add(DollEu1);
        Pannello2.add(DollEu);
        Pannello3.add(DollEu2);

        DollSter1 = new JTextField("0.0");
        DollSter1.setHorizontalAlignment(JTextField.LEFT);
        DollSter1.setPreferredSize(new Dimension(250, 75));
        DollSter1.setFont(new Font("Arial", Font.PLAIN, 25));
        DollSter = new JLabel("Dollaro - Sterlina", JLabel.CENTER);
        DollSter.setPreferredSize(new Dimension(250, 75));
        DollSter2 = new JTextField("0.0");
        DollSter2.setHorizontalAlignment(JTextField.RIGHT);
        DollSter2.setPreferredSize(new Dimension(250, 75));
        DollSter2.setFont(new Font("Arial", Font.PLAIN, 25));
        Pannello.add(DollSter1);
        Pannello2.add(DollSter);
        Pannello3.add(DollSter2);

        DollYen1 = new JTextField("0.0");
        DollYen1.setHorizontalAlignment(JTextField.LEFT);
        DollYen1.setPreferredSize(new Dimension(250, 75));
        DollYen1.setFont(new Font("Arial", Font.PLAIN, 25));
        DollYen = new JLabel("Dollaro - Yen", JLabel.CENTER);
        DollYen.setPreferredSize(new Dimension(250, 75));
        DollYen2 = new JTextField("0.0");
        DollYen2.setHorizontalAlignment(JTextField.RIGHT);
        DollYen2.setPreferredSize(new Dimension(250, 75));
        DollYen2.setFont(new Font("Arial", Font.PLAIN, 25));
        Pannello.add(DollYen1);
        Pannello2.add(DollYen);
        Pannello3.add(DollYen2);

        SterEu1 = new JTextField("0.0");
        SterEu1.setHorizontalAlignment(JTextField.LEFT);
        SterEu1.setPreferredSize(new Dimension(250, 75));
        SterEu = new JLabel("Sterlina - Euro", JLabel.CENTER);
        SterEu1.setFont(new Font("Arial", Font.PLAIN, 25));
        SterEu.setPreferredSize(new Dimension(250, 75));
        SterEu2 = new JTextField("0.0");
        SterEu2.setHorizontalAlignment(JTextField.RIGHT);
        SterEu2.setPreferredSize(new Dimension(250, 75));
        SterEu2.setFont(new Font("Arial", Font.PLAIN, 25));
        Pannello.add(SterEu1);
        Pannello2.add(SterEu);
        Pannello3.add(SterEu2);

        SterYen1 = new JTextField("0.0");
        SterYen1.setHorizontalAlignment(JTextField.LEFT);
        SterYen1.setPreferredSize(new Dimension(250, 75));
        SterYen1.setFont(new Font("Arial", Font.PLAIN, 25));
        SterYen = new JLabel("Sterlina - Yen", JLabel.CENTER);
        SterYen.setPreferredSize(new Dimension(250, 75));
        SterYen2 = new JTextField("0.0");
        SterYen2.setHorizontalAlignment(JTextField.RIGHT);
        SterYen2.setPreferredSize(new Dimension(250, 75));
        SterYen2.setFont(new Font("Arial", Font.PLAIN, 25));
        Pannello.add(SterYen1);
        Pannello2.add(SterYen);
        Pannello3.add(SterYen2);

        EuYen1 = new JTextField("0.0");
        EuYen1.setHorizontalAlignment(JTextField.LEFT);
        EuYen1.setPreferredSize(new Dimension(250, 75));
        EuYen1.setFont(new Font("Arial", Font.PLAIN, 25));
        EuYen = new JLabel("Euro - Yen", JLabel.CENTER);
        EuYen.setPreferredSize(new Dimension(250, 75));
        EuYen2 = new JTextField("0.0");
        EuYen2.setHorizontalAlignment(JTextField.RIGHT);
        EuYen2.setPreferredSize(new Dimension(250, 75));
        EuYen2.setFont(new Font("Arial", Font.PLAIN, 25));
        Pannello.add(EuYen1);
        Pannello2.add(EuYen);
        Pannello3.add(EuYen2);


        Cambio = new JButton("Cambio");
        Cambio.setPreferredSize(new Dimension(250, 75));
        Cambio.setFont(new Font("Arial", Font.BOLD, 25));
        add(Cambio,BorderLayout.NORTH);
        Cancella = new JButton("Cancella");
        Cancella.setPreferredSize(new Dimension(250, 75));
        Cancella.setFont(new Font("Arial", Font.BOLD, 25));
        add(Cancella, BorderLayout.SOUTH);

        add(Pannello, BorderLayout.LINE_START);
        add(Pannello2, BorderLayout.CENTER);
        add(Pannello3, BorderLayout.LINE_END);
        setVisible(true);

        Azioni e = new Azioni();
        Cambio.addActionListener(e);
        Cancella.addActionListener(e);

    }

    private class Azioni implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            switch (e.getActionCommand()){
                case "Cambio":
                    if (!DollEu1.getText().equals("0.0") && !DollEu2.getText().equals("0.0")){
                        DollEu1.setText("Errore");
                        DollEu2.setText("Errore");
                    } else if (!DollEu2.getText().equals("0.0")) {
                        DollEu1.setText(String.valueOf(Math.floor((Float.parseFloat(DollEu2.getText())*1.09)*100.0)/100.0));
                    } else{
                        DollEu2.setText(String.valueOf(Math.floor((Float.parseFloat(DollEu1.getText())*0.91)*100.0)/100.0));
                    }

                    if (!DollSter1.getText().equals("0.0") && !DollSter2.getText().equals("0.0")){
                        DollSter1.setText("Errore");
                        DollSter2.setText("Errore");
                    } else if (!DollSter2.getText().equals("0.0")) {
                        DollSter1.setText(String.valueOf(Math.floor((Float.parseFloat(DollSter2.getText())*1.24)*100.0)/100.0));
                    } else{
                        DollSter2.setText(String.valueOf(Math.floor((Float.parseFloat(DollSter1.getText())*0.80)*100.0)/100.0));
                    }

                    if (!DollYen1.getText().equals("0.0") && !DollYen2.getText().equals("0.0")){
                        DollYen1.setText("Errore");
                        DollYen2.setText("Errore");
                    } else if (!DollYen2.getText().equals("0.0")) {
                        DollYen1.setText(String.valueOf(Math.floor((Float.parseFloat(DollYen2.getText())*0.0092)*100.0)/100.0));
                    } else{
                        DollYen2.setText(String.valueOf(Math.floor((Float.parseFloat(DollYen1.getText())*108.36)*100.0)/100.0));
                    }

                    if (!SterEu1.getText().equals("0.0") && !SterEu2.getText().equals("0.0")){
                        SterEu1.setText("Errore");
                        SterEu2.setText("Errore");
                    } else if (!SterEu2.getText().equals("0.0")) {
                        SterEu1.setText(String.valueOf(Math.floor((Float.parseFloat(SterEu2.getText())*0.80)*100.0)/100.0));
                    } else{
                        SterEu2.setText(String.valueOf(Math.floor((Float.parseFloat(SterEu1.getText())*1.14)*100.0)/100.0));
                    }

                    if (!SterYen1.getText().equals("0.0") && !SterYen2.getText().equals("0.0")){
                        SterYen1.setText("Errore");
                        SterYen2.setText("Errore");
                    } else if (!SterYen2.getText().equals("0.0")) {
                        SterYen1.setText(String.valueOf(Math.floor((Float.parseFloat(SterYen2.getText())*0.0074)*100.0)/100.0));
                    } else{
                        SterYen2.setText(String.valueOf(Math.floor((Float.parseFloat(SterYen1.getText())*134.90)*100.0)/100.0));
                    }

                    if (!EuYen1.getText().equals("0.0") && !EuYen2.getText().equals("0.0")){
                        EuYen1.setText("Errore");
                        EuYen2.setText("Errore");
                    } else if (!EuYen2.getText().equals("0.0")) {
                        EuYen1.setText(String.valueOf(Math.floor((Float.parseFloat(EuYen2.getText())*0.0084)*100.0)/100.0));
                    } else{
                        EuYen2.setText(String.valueOf(Math.floor((Float.parseFloat(EuYen1.getText())*118.48)*100.0)/100.0));
                    }
                    break;
                case "Cancella":
                    DollEu1.setText("0.0");
                    DollEu2.setText("0.0");
                    DollSter1.setText("0.0");
                    DollSter2.setText("0.0");
                    DollYen1.setText("0.0");
                    DollYen2.setText("0.0");
                    SterEu1.setText("0.0");
                    SterEu2.setText("0.0");
                    SterYen1.setText("0.0");
                    SterYen2.setText("0.0");
                    EuYen1.setText("0.0");
                    EuYen2.setText("0.0");
                    break;
            }
        }
    }
    public static void main(){
        new cambiovalute();
    }
}
