package Equivalenze;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class eq extends JFrame{
    JPanel Pannello;
    JLabel EtichettaEq, EtichettaS, EtichettaD;
    JTextField CasellaS, CasellaD;
    JButton Cambio;
    JMenuBar Barra;
    JMenu Menu, Lunghezza, Massa, Capacita;
    JMenuItem Km, Hm, Dam, m, dm, cm, mm;
    JMenuItem Kg, Hg, Dag, g, dg, cg, mg;
    JMenuItem Kl, Hl, Dal, l, dl, cl, ml;

    public eq() {
        super("Equivalenze");
        setSize(600, 300);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        var s = new AzioniS();
        var d = new AzioniD();
        var c = new AzioniC();

        Pannello = new JPanel();
        Pannello.setBackground(Color.orange);
        Pannello.setLayout(null);

        EtichettaEq = new JLabel("EQUIVALENZE", JLabel.CENTER);
        EtichettaEq.setFont(new Font("Arial", Font.BOLD,25));
        add(EtichettaEq, BorderLayout.NORTH);
        EtichettaS = new JLabel("", JLabel.CENTER);
        EtichettaS.setFont(new Font("Arial", Font.BOLD,15));
        EtichettaS.setBounds(50,40,100,30);
        Pannello.add(EtichettaS);
        EtichettaD = new JLabel("", JLabel.CENTER);
        EtichettaD.setFont(new Font("Arial", Font.BOLD,15));
        EtichettaD.setBounds(440,40,100,30);
        Pannello.add(EtichettaD);

        Lunghezza = new JMenu("--Lunghezza--");
        Km = new JMenuItem("Chilometri");
        Hm = new JMenuItem("Ettometri");
        Dam = new JMenuItem("Decametri");
        m = new JMenuItem("Metri");
        dm = new JMenuItem("Decimetri");
        cm = new JMenuItem("Centimetri");
        mm = new JMenuItem("Millimetri");

        Massa = new JMenu("--Massa--");
        Kg = new JMenuItem("Chilogrammi");
        Hg = new JMenuItem("Ettogrammi");
        Dag = new JMenuItem("Decagrammi");
        g = new JMenuItem("Grammi");
        dg = new JMenuItem("Decigrammi");
        cg = new JMenuItem("Centigrammi");
        mg = new JMenuItem("Milligrammi");

        Capacita = new JMenu("--Capacità--");
        Kl = new JMenuItem("Chilolitri");
        Hl = new JMenuItem("Ettolitri");
        Dal = new JMenuItem("Decalitri");
        l = new JMenuItem("Litri");
        dl = new JMenuItem("Decilitri");
        cl = new JMenuItem("Centilitri");
        ml = new JMenuItem("Millilitri");

        Km.addActionListener(s);
        Hm.addActionListener(s);
        Dam.addActionListener(s);
        m.addActionListener(s);
        dm.addActionListener(s);
        cm.addActionListener(s);
        mm.addActionListener(s);

        Kg.addActionListener(s);
        Hg.addActionListener(s);
        Dag.addActionListener(s);
        g.addActionListener(s);
        dg.addActionListener(s);
        cg.addActionListener(s);
        mg.addActionListener(s);

        Kl.addActionListener(s);
        Hl.addActionListener(s);
        Dal.addActionListener(s);
        l.addActionListener(s);
        dl.addActionListener(s);
        cl.addActionListener(s);
        ml.addActionListener(s);

        Barra = new JMenuBar();
        Barra.setBounds(205,15,60,20);
        Menu = new JMenu("Misura");
        Menu.add(Lunghezza);
        Lunghezza.add(Km);
        Lunghezza.add(Hm);
        Lunghezza.add(Dam);
        Lunghezza.add(m);
        Lunghezza.add(dm);
        Lunghezza.add(cm);
        Lunghezza.add(mm);
        Menu.add(Massa);
        Massa.add(Kg);
        Massa.add(Hg);
        Massa.add(Dag);
        Massa.add(g);
        Massa.add(dg);
        Massa.add(cg);
        Massa.add(mg);
        Menu.add(Capacita);
        Capacita.add(Kl);
        Capacita.add(Hl);
        Capacita.add(Dal);
        Capacita.add(l);
        Capacita.add(dl);
        Capacita.add(cl);
        Capacita.add(ml);
        Barra.add(Menu);
        Pannello.add(Barra);

        Lunghezza = new JMenu("--Lunghezza--");
        Km = new JMenuItem("Chilometri");
        Hm = new JMenuItem("Ettometri");
        Dam = new JMenuItem("Decametri");
        m = new JMenuItem("Metri");
        dm = new JMenuItem("Decimetri");
        cm = new JMenuItem("Centimetri");
        mm = new JMenuItem("Millimetri");

        Massa = new JMenu("--Massa--");
        Kg = new JMenuItem("Chilogrammi");
        Hg = new JMenuItem("Ettogrammi");
        Dag = new JMenuItem("Decagrammi");
        g = new JMenuItem("Grammi");
        dg = new JMenuItem("Decigrammi");
        cg = new JMenuItem("Centigrammi");
        mg = new JMenuItem("Milligrammi");

        Capacita = new JMenu("--Capacità--");
        Kl = new JMenuItem("Chilolitri");
        Hl = new JMenuItem("Ettolitri");
        Dal = new JMenuItem("Decalitri");
        l = new JMenuItem("Litri");
        dl = new JMenuItem("Decilitri");
        cl = new JMenuItem("Centilitri");
        ml = new JMenuItem("Millilitri");

        Km.addActionListener(d);
        Hm.addActionListener(d);
        Dam.addActionListener(d);
        m.addActionListener(d);
        dm.addActionListener(d);
        cm.addActionListener(d);
        mm.addActionListener(d);

        Kg.addActionListener(d);
        Hg.addActionListener(d);
        Dag.addActionListener(d);
        g.addActionListener(d);
        dg.addActionListener(d);
        cg.addActionListener(d);
        mg.addActionListener(d);

        Kl.addActionListener(d);
        Hl.addActionListener(d);
        Dal.addActionListener(d);
        l.addActionListener(d);
        dl.addActionListener(d);
        cl.addActionListener(d);
        ml.addActionListener(d);

        Barra = new JMenuBar();
        Barra.setBounds(335,15,60,20);
        Menu = new JMenu("Misura");
        Menu.add(Lunghezza);
        Lunghezza.add(Km);
        Lunghezza.add(Hm);
        Lunghezza.add(Dam);
        Lunghezza.add(m);
        Lunghezza.add(dm);
        Lunghezza.add(cm);
        Lunghezza.add(mm);
        Menu.add(Massa);
        Massa.add(Kg);
        Massa.add(Hg);
        Massa.add(Dag);
        Massa.add(g);
        Massa.add(dg);
        Massa.add(cg);
        Massa.add(mg);
        Menu.add(Capacita);
        Capacita.add(Kl);
        Capacita.add(Hl);
        Capacita.add(Dal);
        Capacita.add(l);
        Capacita.add(dl);
        Capacita.add(cl);
        Capacita.add(ml);
        Barra.add(Menu);
        Pannello.add(Barra);

        CasellaS = new JTextField("");
        CasellaS.setHorizontalAlignment(JTextField.RIGHT);
        CasellaS.setFont(new Font("Arial", Font.BOLD,35));
        CasellaS.setBounds(10,100,255,40);
        Pannello.add(CasellaS);

        CasellaD = new JTextField("");
        CasellaD.setHorizontalAlignment(JTextField.RIGHT);
        CasellaD.setFont(new Font("Arial", Font.BOLD,35));
        CasellaD.setBounds(335,100,255,40);
        Pannello.add(CasellaD);

        Cambio = new JButton("CAMBIO");
        Cambio.setFont(new Font("Arial", Font.BOLD,25));
        Cambio.setBounds(228,170, 145,40);
        Cambio.addActionListener(c);
        Pannello.add(Cambio);

        add(Pannello);
        setVisible(true);
    }

    private class AzioniS implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            EtichettaS.setText(e.getActionCommand());
        }
    }
    private class AzioniD implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            EtichettaD.setText(e.getActionCommand());
        }
    }
    private class AzioniC implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            var cambio = new Cambio();
            if (CasellaD.getText().equals("")){
                switch (EtichettaS.getText()){
                    case "Chilometri":
                        switch (EtichettaD.getText()) {
                            case "Chilometri" -> CasellaD.setText(CasellaS.getText());
                            case "Ettometri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Decametri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Metri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Decimetri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            case "Centimetri" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                            case "Millimetri" -> CasellaD.setText(cambio.Mmilione(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Ettometri":
                        switch (EtichettaD.getText()) {
                            case "Chilometri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Ettometri" -> CasellaD.setText(CasellaS.getText());
                            case "Decametri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Metri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Decimetri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Centimetri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            case "Millimetri" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Decametri":
                        switch (EtichettaD.getText()) {
                            case "Chilometri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Ettometri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Decametri" -> CasellaD.setText(CasellaS.getText());
                            case "Metri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Decimetri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Centimetri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Millimetri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Metri":
                        switch (EtichettaD.getText()) {
                            case "Chilometri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Ettometri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Decametri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Metri" -> CasellaD.setText(CasellaS.getText());
                            case "Decimetri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Centimetri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Millimetri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Decimetri":
                        switch (EtichettaD.getText()) {
                            case "Chilometri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Ettometri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Decametri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Metri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Decimetri" -> CasellaD.setText(CasellaS.getText());
                            case "Centimetri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Millimetri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Centimetri":
                        switch (EtichettaD.getText()) {
                            case "Chilometri" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                            case "Ettometri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Decametri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Metri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Decimetri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Centimetri" -> CasellaD.setText(CasellaS.getText());
                            case "Millimetri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Millimetri":
                        switch (EtichettaD.getText()) {
                            case "Chilometri" -> CasellaD.setText(cambio.Dmilione(CasellaS.getText()));
                            case "Ettometri" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                            case "Decametri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Metri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Decimetri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Centimetri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Millimetri" -> CasellaD.setText(CasellaS.getText());
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Chilogrammi":
                        switch (EtichettaD.getText()) {
                            case "Chilogrammi" -> CasellaD.setText(CasellaS.getText());
                            case "Ettogrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Decagrammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Grammi" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Decigrammi" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            case "Centigrammi" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                            case "Milligrammi" -> CasellaD.setText(cambio.Mmilione(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Ettogrammi":
                        switch (EtichettaD.getText()) {
                            case "Chilogrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Ettogrammi" -> CasellaD.setText(CasellaS.getText());
                            case "Decagrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Grammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Decigrammi" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Centigrammi" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            case "Milligrammi" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Decagrammi":
                        switch (EtichettaD.getText()) {
                            case "Chilogrammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Ettogrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Decagrammi" -> CasellaD.setText(CasellaS.getText());
                            case "Grammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Decigrammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Centigrammi" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Milligrammi" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Grammi":
                        switch (EtichettaD.getText()) {
                            case "Chilogrammi" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Ettogrammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Decagrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Grammi" -> CasellaD.setText(CasellaS.getText());
                            case "Decigrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Centigrammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Milligrammi" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Decigrammi":
                        switch (EtichettaD.getText()) {
                            case "Chilogrammi" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Ettogrammi" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Decagrammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Grammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Decigrammi" -> CasellaD.setText(CasellaS.getText());
                            case "Centigrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Milligrammi" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Centigrammi":
                        switch (EtichettaD.getText()) {
                            case "Chilogrammi" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                            case "Ettogrammi" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Decagrammi" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Grammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Decigrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Centigrammi" -> CasellaD.setText(CasellaS.getText());
                            case "Milligrammi" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Milligrammi":
                        switch (EtichettaD.getText()) {
                            case "Chilogrammi" -> CasellaD.setText(cambio.Dmilione(CasellaS.getText()));
                            case "Ettogrammi" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                            case "Decagrammi" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Grammi" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Decigrammi" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Centigrammi" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Milligrammi" -> CasellaD.setText(CasellaS.getText());
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Chilolitri":
                        switch (EtichettaD.getText()) {
                            case "Chilolitri" -> CasellaD.setText(CasellaS.getText());
                            case "Ettolitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Decalitri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Litro" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Decilitri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            case "Centolitri" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                            case "Millilitri" -> CasellaD.setText(cambio.Mmilione(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Ettolitri":
                        switch (EtichettaD.getText()) {
                            case "Chilolitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Ettolitri" -> CasellaD.setText(CasellaS.getText());
                            case "Decalitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Litro" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Decilitri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Centolitri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            case "Millilitri" -> CasellaD.setText(cambio.Mcmila(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Decalitri":
                        switch (EtichettaD.getText()) {
                            case "Chilolitri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Ettolitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Decalitri" -> CasellaD.setText(CasellaS.getText());
                            case "Litro" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Decilitri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Centolitri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            case "Millilitri" -> CasellaD.setText(cambio.Mdmila(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Litri":
                        switch (EtichettaD.getText()) {
                            case "Chilolitri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Ettolitri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Decalitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Litri" -> CasellaD.setText(CasellaS.getText());
                            case "Decilitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Centolitri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            case "Millilitri" -> CasellaD.setText(cambio.Mmille(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Decilitri":
                        switch (EtichettaD.getText()) {
                            case "Chilolitri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Ettolitri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Decalitri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Litri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Decilitri" -> CasellaD.setText(CasellaS.getText());
                            case "Centolitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            case "Millilitri" -> CasellaD.setText(cambio.Mcento(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Centilitri":
                        switch (EtichettaD.getText()) {
                            case "Chilolitri" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                            case "Ettolitri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Decalitri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Litro" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Decilitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Centolitri" -> CasellaD.setText(CasellaS.getText());
                            case "Millilitri" -> CasellaD.setText(cambio.Mdieci(CasellaS.getText()));
                            default -> CasellaD.setText("Errore");
                        }
                        break;
                    case "Millitro":
                        switch (EtichettaD.getText()) {
                            case "Chilolitri" -> CasellaD.setText(cambio.Dmilione(CasellaS.getText()));
                            case "Ettolitri" -> CasellaD.setText(cambio.Dcmila(CasellaS.getText()));
                            case "Decalitri" -> CasellaD.setText(cambio.Ddmila(CasellaS.getText()));
                            case "Litri" -> CasellaD.setText(cambio.Dmille(CasellaS.getText()));
                            case "Decilitri" -> CasellaD.setText(cambio.Dcento(CasellaS.getText()));
                            case "Centolitri" -> CasellaD.setText(cambio.Ddieci(CasellaS.getText()));
                            case "Millilitri" -> CasellaD.setText(CasellaS.getText());
                            default -> CasellaD.setText("Errore");
                        }
                        break;

                    default:
                        CasellaD.setText("Errore");
                        break;
                }
            }else if(CasellaS.getText().equals("")){
                switch (EtichettaD.getText()){
                    case "Chilometri":
                        switch (EtichettaS.getText()) {
                            case "Chilometri" -> CasellaS.setText(CasellaD.getText());
                            case "Ettometri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Decametri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Metri" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Decimetri" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            case "Centimetri" -> CasellaS.setText(cambio.Mcmila(CasellaD.getText()));
                            case "Millimetri" -> CasellaS.setText(cambio.Mmilione(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Ettometri":
                        switch (EtichettaS.getText()) {
                            case "Chilometri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Ettometri" -> CasellaS.setText(CasellaD.getText());
                            case "Decametri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Metri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Decimetri" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Centimetri" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            case "Millimetri" -> CasellaS.setText(cambio.Mcmila(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Decametri":
                        switch (EtichettaS.getText()) {
                            case "Chilometri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Ettometri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Decametri" -> CasellaS.setText(CasellaD.getText());
                            case "Metri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Decimetri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Centimetri" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Millimetri" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Metri":
                        switch (EtichettaS.getText()) {
                            case "Chilometri" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Ettometri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Decametri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Metri" -> CasellaS.setText(CasellaD.getText());
                            case "Decimetri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Centimetri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Millimetri" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Decimetri":
                        switch (EtichettaS.getText()) {
                            case "Chilometri" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Ettometri" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Decametri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Metri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Decimetri" -> CasellaS.setText(CasellaD.getText());
                            case "Centimetri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Millimetri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Centimetri":
                        switch (EtichettaS.getText()) {
                            case "Chilometri" -> CasellaS.setText(cambio.Dcmila(CasellaD.getText()));
                            case "Ettometri" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Decametri" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Metri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Decimetri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Centimetri" -> CasellaS.setText(CasellaD.getText());
                            case "Millimetri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Millimetri":
                        switch (EtichettaS.getText()) {
                            case "Chilometri" -> CasellaS.setText(cambio.Dmilione(CasellaD.getText()));
                            case "Ettometri" -> CasellaS.setText(cambio.Dcmila(CasellaD.getText()));
                            case "Decametri" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Metri" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Decimetri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "centrimetri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Millimetri" -> CasellaS.setText(CasellaD.getText());
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Chilogrammi":
                        switch (EtichettaS.getText()) {
                            case "Chilogrammi" -> CasellaS.setText(CasellaD.getText());
                            case "Ettogrammi" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Decagrammi" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Grammi" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Decigrammi" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            case "Centigrammi" -> CasellaS.setText(cambio.Mcmila(CasellaD.getText()));
                            case "Milligrammi" -> CasellaS.setText(cambio.Mmilione(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Ettogrammi":
                        switch (EtichettaS.getText()) {
                            case "Chilogrammi" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Ettogrammi" -> CasellaS.setText(CasellaD.getText());
                            case "Decagrammi" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Grammi" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Decigrammi" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Centigrammi" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            case "Milligrammi" -> CasellaS.setText(cambio.Mcmila(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Decagrammi":
                        switch (EtichettaS.getText()) {
                            case "Chilogrammi" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Ettogrammi" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Decagrammi" -> CasellaS.setText(CasellaD.getText());
                            case "Grammi" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Decigrammi" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Centigrammi" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Milligrammi" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Grammi":
                        switch (EtichettaS.getText()) {
                            case "Chilogrammi" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Ettogrammi" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Decagrammi" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Grammi" -> CasellaS.setText(CasellaD.getText());
                            case "Decigrammi" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Centigrammi" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Milligrammi" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Decigrammi":
                        switch (EtichettaS.getText()) {
                            case "Chilogrammi" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Ettogrammi" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Decagrammi" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Grammi" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Decigrammi" -> CasellaS.setText(CasellaD.getText());
                            case "Centigrammi" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Milligrammi" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Centigrammi":
                        switch (EtichettaS.getText()) {
                            case "Chilogrammi" -> CasellaS.setText(cambio.Dcmila(CasellaD.getText()));
                            case "Ettogrammi" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Decagrammi" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Grammi" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Decigrammi" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Centigrammi" -> CasellaS.setText(CasellaD.getText());
                            case "Milligrammi" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Milligrammi":
                        switch (EtichettaS.getText()) {
                            case "Chilogrammi" -> CasellaS.setText(cambio.Dmilione(CasellaD.getText()));
                            case "Ettogrammi" -> CasellaS.setText(cambio.Dcmila(CasellaD.getText()));
                            case "Decagrammi" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Grammi" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Decigrammi" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Centigrammi" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Milligrammi" -> CasellaS.setText(CasellaD.getText());
                            default -> CasellaS.setText("Errore");
                        }
                    case "Chilolitri":
                        switch (EtichettaS.getText()) {
                            case "Chilolitri" -> CasellaS.setText(CasellaD.getText());
                            case "Ettolitri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Decalitri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Litri" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Decilitri" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            case "Centilitri" -> CasellaS.setText(cambio.Mcmila(CasellaD.getText()));
                            case "Millilitri" -> CasellaS.setText(cambio.Mmilione(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Ettolitri":
                        switch (EtichettaS.getText()) {
                            case "Chilolitri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Ettolitri" -> CasellaS.setText(CasellaD.getText());
                            case "Decalitri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Litri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Decilitri" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Centilitri" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            case "Millilitri" -> CasellaS.setText(cambio.Mcmila(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Decalitri":
                        switch (EtichettaS.getText()) {
                            case "Chilolitri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Ettolitri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Decalitri" -> CasellaS.setText(CasellaD.getText());
                            case "Litri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Decilitri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Centilitri" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            case "Millilitri" -> CasellaS.setText(cambio.Mdmila(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Litri":
                        switch (EtichettaS.getText()) {
                            case "Chilolitri" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Ettolitri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Decalitri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Litri" -> CasellaS.setText(CasellaD.getText());
                            case "Decilitri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Centilitri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            case "Millilitri" -> CasellaS.setText(cambio.Mmille(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Decilitri":
                        switch (EtichettaS.getText()) {
                            case "Chilolitri" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Ettolitri" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Decalitri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Litri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Decilitri" -> CasellaS.setText(CasellaD.getText());
                            case "Centilitri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            case "Millilitri" -> CasellaS.setText(cambio.Mcento(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Centilitri":
                        switch (EtichettaS.getText()) {
                            case "Chilolitri" -> CasellaS.setText(cambio.Dcmila(CasellaD.getText()));
                            case "Ettolitri" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Decalitri" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Litri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Decilitri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Centilitri" -> CasellaS.setText(CasellaD.getText());
                            case "Millilitri" -> CasellaS.setText(cambio.Mdieci(CasellaD.getText()));
                            default -> CasellaS.setText("Errore");
                        }
                        break;
                    case "Millilitri":
                        switch (EtichettaS.getText()) {
                            case "Chilolitri" -> CasellaS.setText(cambio.Dmilione(CasellaD.getText()));
                            case "Ettolitri" -> CasellaS.setText(cambio.Dcmila(CasellaD.getText()));
                            case "Decalitri" -> CasellaS.setText(cambio.Ddmila(CasellaD.getText()));
                            case "Litri" -> CasellaS.setText(cambio.Dmille(CasellaD.getText()));
                            case "Decilitri" -> CasellaS.setText(cambio.Dcento(CasellaD.getText()));
                            case "Centilitri" -> CasellaS.setText(cambio.Ddieci(CasellaD.getText()));
                            case "Millilitri" -> CasellaS.setText(CasellaD.getText());
                            default -> CasellaS.setText("Errore");
                        }
                }
            }else{
                CasellaS.setText("Errore");
                CasellaD.setText("Errore");
            }
        }
    }

    private static class Cambio {
        String Ddieci(String a){
            return String.valueOf(Float.parseFloat(a)/10);
        }
        String Dcento(String a){
            return String.valueOf(Float.parseFloat(a)/100);
        }
        String Dmille(String a){
            return String.valueOf(Float.parseFloat(a)/1000);
        }
        String Ddmila(String a){
            return String.valueOf(Float.parseFloat(a)/10000);
        }
        String Dcmila(String a){
            return String.valueOf(Float.parseFloat(a)/100000);
        }
        String Dmilione(String a){
            return String.valueOf(Float.parseFloat(a)/1000000);
        }
        String Mdieci(String a){
            return String.valueOf(Float.parseFloat(a)*10);
        }
        String Mcento(String a){
            return String.valueOf(Float.parseFloat(a)*100);
        }
        String Mmille(String a){
            return String.valueOf(Float.parseFloat(a)*1000);
        }
        String Mdmila(String a){
            return String.valueOf(Float.parseFloat(a)*10000);
        }
        String Mcmila(String a){
            return String.valueOf(Float.parseFloat(a)*100000);
        }
        String Mmilione(String a){
            return String.valueOf(Float.parseFloat(a)*1000000);
        }
    }

    public static void main(){
        new eq();
    }
}


