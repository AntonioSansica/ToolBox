package Calcolatrice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calcA extends JFrame{
    JPanel Pannello;
    JTextField Testo;
    JButton Piu, Meno, Diviso, Per, Uguale, Cancella, Radice, RadiceCubica, Potenza, Seno, Coseno, Tangente, PI, Punto, Canc, Percentuale;
    JButton[] Numeri = new JButton[10];

    private calcA() {
        // Costruzione Finestra Calcolatrice Avanzata
        super("Calcoltrice Avanzata");
        setSize(500, 500);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Dichiarazione JPanel, Area Testo e Bottone Cancella
        Testo = new JTextField();
        Testo.setHorizontalAlignment(JTextField.RIGHT);
        Testo.setEnabled(true);
        Testo.setDisabledTextColor(Color.BLACK);
        Testo.setPreferredSize(new Dimension(400, 85));
        Testo.setBackground(Color.white);
        Testo.setFont(new Font("Arial", Font.PLAIN, 40));
        add(Testo, BorderLayout.NORTH);

        Cancella = new JButton("Cancella");
        Cancella.setPreferredSize(new Dimension(400, 45));
        Cancella.setBackground(Color.red);
        add(Cancella, BorderLayout.SOUTH);

        Pannello = new JPanel();
        Pannello.setBackground(Color.red);
        Pannello.setLayout(new GridLayout(5, 5));

        //Creazione bottoni essenziali ed implementazione classe Azioni
        Piu = new JButton("+");
        Piu.setBackground(Color.orange);
        Meno = new JButton("-");
        Meno.setBackground(Color.orange);
        Per = new JButton("*");
        Per.setBackground(Color.orange);
        Canc = new JButton("<--");
        Canc.setBackground(Color.red);
        Uguale = new JButton("=");
        Uguale.setBackground(Color.orange);
        Diviso = new JButton("/");
        Diviso.setBackground(Color.orange);
        Radice = new JButton("√");
        Radice.setBackground(Color.orange);
        RadiceCubica = new JButton("3√");
        RadiceCubica.setBackground(Color.orange);
        Percentuale = new JButton("%");
        Percentuale.setBackground(Color.orange);
        Potenza = new JButton("x^y");
        Potenza.setBackground(Color.orange);
        Seno = new JButton("sin");
        Seno.setBackground(Color.green);
        Coseno = new JButton("cos");
        Coseno.setBackground(Color.green);
        Tangente = new JButton("tan");
        Tangente.setBackground(Color.green);
        PI = new JButton("π");
        PI.setBackground(Color.green);
        Punto = new JButton(".");

        Azioni e = new Azioni();

        e.iniz();       //inizializzazione vettore per operazioni

        Piu.addActionListener(e);
        Meno.addActionListener(e);
        Per.addActionListener(e);
        Diviso.addActionListener(e);
        Uguale.addActionListener(e);
        Canc.addActionListener(e);
        Radice.addActionListener(e);
        RadiceCubica.addActionListener(e);
        Potenza.addActionListener(e);
        Percentuale.addActionListener(e);
        PI.addActionListener(e);
        Seno.addActionListener(e);
        Coseno.addActionListener(e);
        Tangente.addActionListener(e);
        Punto.addActionListener(e);
        Cancella.addActionListener(e);

        for (int i = 9; i != -1; i--) {
            Numeri[i] = new JButton("" + i);
            Numeri[i].addActionListener(e);
        }

        //Aggiunta Bottoni al JPanel dichiarato
        Pannello.add(Seno);
        Pannello.add(Coseno);
        Pannello.add(Tangente);
        Pannello.add(Potenza);
        Pannello.add(Canc);

        Pannello.add(Numeri[9]);
        Pannello.add(Numeri[8]);
        Pannello.add(Numeri[7]);
        Pannello.add(Radice);
        Pannello.add(RadiceCubica);

        Pannello.add(Numeri[6]);
        Pannello.add(Numeri[5]);
        Pannello.add(Numeri[4]);
        Pannello.add(Piu);
        Pannello.add(Meno);

        Pannello.add(Numeri[3]);
        Pannello.add(Numeri[2]);
        Pannello.add(Numeri[1]);
        Pannello.add(Per);
        Pannello.add(Diviso);

        Pannello.add(PI);
        Pannello.add(Numeri[0]);
        Pannello.add(Punto);
        Pannello.add(Percentuale);
        Pannello.add(Uguale);


        add(Pannello);
        setVisible(true);
    }

    private class Azioni implements ActionListener {
        String[] Espressione = new String[100];     //Dichiarazione vettore che conterrà le operazioni svolte
        int i = 0;
        float Ris = 0;
        void iniz(){                                //Metodo inizializza vettore
            for (int k = 0; k < 100; k++){
                Espressione[k] = "";
            }
        }
        public void actionPerformed(ActionEvent e) {        //metodo azione alla pressione del bottone
            switch (e.getActionCommand()) {
                case "Cancella":                                   //Reinizializzazione del vettore, della variabile Ris, della varibile di iterazione i  alla pressione del tasto C
                    Espressione = new String[100];
                    Testo.setText("Ciao");
                    iniz();
                    Ris = 0;
                    i = 0;
                    break;
                case "<--":
                    if (!Espressione[i+1].equals(String.valueOf(Ris))) {
                        Espressione[i] = Espressione[i].substring(0, Espressione[i].length() - 1);
                        Testo.setText(Espressione[i]);
                    }
                    break;
                case "=":                                  //Calcolo e stampa a schermo dell'operazione corrente
                    Ris = RisolviEspressione(Espressione, i);
                    Testo.setText(String.valueOf(Ris));
                    Espressione[i+1] = String.valueOf(Ris);
                    break;
                case "√":
                    Espressione[i] = String.valueOf(Math.sqrt(Double.parseDouble(Espressione[i])));
                    Testo.setText(Espressione[i]);
                    break;
                case "3√":
                    Espressione[i] = String.valueOf(Math.pow(Double.parseDouble(Espressione[i]),(1 / 3.0)));
                    Testo.setText(Espressione[i]);
                    break;
                case "π":
                    Espressione[i] = String.valueOf(Double.parseDouble(Espressione[i])*3.14159);
                    Testo.setText(Espressione[i]);
                    break;
                case "sin":
                    Espressione[i] = String.valueOf(Math.sin(Math.toRadians(Double.parseDouble(Espressione[i]))));
                    Testo.setText(Espressione[i]);
                    break;
                case "cos":
                    Espressione[i] = String.valueOf(Math.cos(Math.toRadians(Double.parseDouble(Espressione[i]))));
                    Testo.setText(Espressione[i]);
                    break;
                case "tan":
                    Espressione[i] = String.valueOf(Math.tan(Math.toRadians(Double.parseDouble(Espressione[i]))));
                    Testo.setText(Espressione[i]);
                    break;
                case ".":
                    Espressione[i] += ".";
                    Testo.setText(Espressione[i]);
                    break;
                default:
                    if (!e.getActionCommand().equals("+") && !e.getActionCommand().equals("-") && !e.getActionCommand().equals("*") && !e.getActionCommand().equals("/") && !e.getActionCommand().equals("x^y") && !e.getActionCommand().equals("%")) {
                        Espressione[i] += e.getActionCommand();
                        Testo.setText(Espressione[i]);
                    }
                    else {                                                              //finchè non viene premuto un Bottone Operando, C o =, vi è la possibilità di scrivere il numero desiderato
                        if (i == 2 || (i > 3 && i % 2 == 0)) {                          //alla pressione di un tasto Operando, prima si controlla il valore di i e se rispecchia una delle condizioni
                            Ris = RisolviEspressione(Espressione, i);                   //descritte si calcola il risultato e si sostituisce al valore della posizione corrente nel vettore
                            Espressione[i] = String.valueOf(Ris);                       //fatto ciò si incrementa di 1 la varibile i e si inserisce nel vettore l'operando ed infine si incrementa nuovamente la varibile i
                        }
                        i++;
                        Espressione[i] = e.getActionCommand();
                        Testo.setText(Espressione[i]);
                        i++;
                    }
                    break;
            }
        }

        public float RisolviEspressione(String[] Espressione, int a){                   //metodo risolvi operazione da svolgere
            float ris = 0;
            float b = Float.parseFloat(Espressione[a-2]);
            float c = Float.parseFloat(Espressione[a]);

            ris = switch (Espressione[a - 1]) {
                case "+" -> b + c;
                case "-" -> b - c;
                case "*" -> b * c;
                case "/" -> b / c;
                case "x^y" -> (float) Math.pow(b, c);
                case "%" -> ((c / 100) * b);
                default -> 0;
            };

            return ris;
        }
    }

    public static void main(){
        new calcA();
    }
}

